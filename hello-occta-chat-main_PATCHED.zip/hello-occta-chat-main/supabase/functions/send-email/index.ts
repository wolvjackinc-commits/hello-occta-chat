import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resendApiKey = Deno.env.get("RESEND_API_KEY");
const resend = new Resend(resendApiKey);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface EmailRequest {
  type:
    | "order_confirmation"
    | "welcome"
    | "status_update"
    | "order_message"
    | "ticket_reply"
    | "password_reset";
  to: string;
  data: Record<string, unknown>;
  // For guest order confirmations - order verification data
  orderNumber?: string;
  redirectTo?: string;
}

// HTML escape helper to prevent injection attacks
const escapeHtml = (unsafe: unknown): string => {
  if (unsafe === null || unsafe === undefined) return '';
  const str = String(unsafe);
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
};

// Sanitize numeric values
const sanitizeNumber = (value: unknown): string => {
  const num = parseFloat(String(value));
  return isNaN(num) ? '0.00' : num.toFixed(2);
};

const getOrderConfirmationHtml = (data: Record<string, unknown>) => `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@400;600;700;900&display=swap');
    
    body { margin: 0; padding: 0; background: #f5f4ef; color: #0d0d0d; font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; }
    .preheader { display: none !important; visibility: hidden; opacity: 0; height: 0; width: 0; max-height: 0; max-width: 0; overflow: hidden; }
    
    .wrapper { background: #f5f4ef; padding: 40px 20px; }
    .container { max-width: 600px; margin: 0 auto; background: #ffffff; border: 4px solid #0d0d0d; box-shadow: 8px 8px 0 0 #0d0d0d; }
    
    /* Header with brutalist styling */
    .header { background: #0d0d0d; padding: 32px; position: relative; overflow: hidden; }
    .header::before { content: ''; position: absolute; top: 0; right: 0; width: 120px; height: 120px; background: #facc15; transform: translate(30%, -30%) rotate(45deg); }
    .logo { font-family: 'Bebas Neue', sans-serif; font-size: 32px; letter-spacing: 4px; color: #ffffff; text-transform: uppercase; position: relative; z-index: 1; }
    .tagline { font-size: 11px; letter-spacing: 3px; text-transform: uppercase; color: #facc15; margin-top: 4px; font-weight: 600; }
    
    /* Title banner */
    .title-banner { background: #facc15; padding: 16px 32px; border-bottom: 4px solid #0d0d0d; }
    .title { font-family: 'Bebas Neue', sans-serif; font-size: 28px; letter-spacing: 2px; text-transform: uppercase; margin: 0; color: #0d0d0d; }
    
    /* Content area */
    .content { padding: 32px; }
    .greeting { font-size: 18px; font-weight: 700; margin-bottom: 16px; }
    .text { font-size: 15px; line-height: 1.7; color: #333; margin: 16px 0; }
    
    /* Order details card */
    .order-card { background: #f5f4ef; border: 3px solid #0d0d0d; margin: 24px 0; }
    .order-header { background: #0d0d0d; color: #fff; padding: 12px 20px; font-family: 'Bebas Neue', sans-serif; font-size: 16px; letter-spacing: 2px; text-transform: uppercase; }
    .order-body { padding: 20px; }
    .order-row { display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px dashed #ccc; }
    .order-row:last-child { border-bottom: none; padding-bottom: 0; }
    .order-label { font-size: 12px; text-transform: uppercase; letter-spacing: 1px; color: #666; font-weight: 600; }
    .order-value { font-size: 15px; font-weight: 700; text-align: right; max-width: 60%; }
    .order-highlight { background: #facc15; padding: 2px 8px; display: inline-block; }
    
    /* Steps section */
    .steps { margin: 28px 0; padding: 24px; background: linear-gradient(135deg, #f5f4ef 0%, #fff 100%); border-left: 4px solid #facc15; }
    .steps-title { font-family: 'Bebas Neue', sans-serif; font-size: 18px; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 16px; }
    .step { display: flex; align-items: flex-start; margin: 12px 0; }
    .step-num { background: #0d0d0d; color: #facc15; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; font-weight: 900; font-size: 14px; margin-right: 12px; flex-shrink: 0; }
    .step-text { font-size: 14px; line-height: 1.5; padding-top: 4px; }
    
    /* CTA Button */
    .cta-wrap { text-align: center; margin: 32px 0; }
    .cta { display: inline-block; background: #0d0d0d; color: #ffffff; padding: 16px 40px; text-decoration: none; font-family: 'Bebas Neue', sans-serif; font-size: 18px; letter-spacing: 2px; text-transform: uppercase; border: 3px solid #0d0d0d; box-shadow: 4px 4px 0 0 #facc15; transition: all 0.15s; }
    .cta:hover { transform: translate(-2px, -2px); box-shadow: 6px 6px 0 0 #facc15; }
    
    /* Order number callout */
    .order-callout { text-align: center; background: #f5f4ef; border: 2px dashed #0d0d0d; padding: 16px; margin: 24px 0; }
    .order-callout-label { font-size: 11px; text-transform: uppercase; letter-spacing: 2px; color: #666; }
    .order-callout-number { font-family: 'Bebas Neue', sans-serif; font-size: 24px; letter-spacing: 3px; margin-top: 4px; }
    
    /* Footer */
    .footer { background: #0d0d0d; padding: 28px 32px; }
    .footer-content { text-align: center; }
    .footer-logo { font-family: 'Bebas Neue', sans-serif; font-size: 20px; letter-spacing: 3px; color: #facc15; }
    .footer-links { margin: 16px 0; }
    .footer-link { color: #ffffff; text-decoration: none; font-size: 12px; margin: 0 12px; text-transform: uppercase; letter-spacing: 1px; }
    .footer-text { color: #888; font-size: 11px; margin-top: 16px; }
    .footer-address { color: #666; font-size: 11px; margin-top: 8px; line-height: 1.6; }
  </style>
</head>
<body>
  <div class="preheader">Your OCCTA order #${escapeHtml(data.order_number)} is confirmed! We're getting everything ready for you.</div>
  
  <div class="wrapper">
    <div class="container">
      <!-- Header -->
      <div class="header">
        <div class="logo">OCCTA</div>
        <div class="tagline">Telecom • Connected</div>
      </div>
      
      <!-- Title Banner -->
      <div class="title-banner">
        <h1 class="title">✓ Order Confirmed</h1>
      </div>
      
      <!-- Content -->
      <div class="content">
        <p class="greeting">Hi ${escapeHtml(data.full_name)},</p>
        <p class="text">Brilliant news! Your order is locked in and we're already on it. Here's everything you need to know:</p>
        
        <!-- Order Details Card -->
        <div class="order-card">
          <div class="order-header">Order Details</div>
          <div class="order-body">
            <div class="order-row">
              <span class="order-label">Order Number</span>
              <span class="order-value"><span class="order-highlight">${escapeHtml(data.order_number)}</span></span>
            </div>
            <div class="order-row">
              <span class="order-label">Service</span>
              <span class="order-value">${escapeHtml(data.service_type)}</span>
            </div>
            <div class="order-row">
              <span class="order-label">Plan</span>
              <span class="order-value">${escapeHtml(data.plan_name)}</span>
            </div>
            <div class="order-row">
              <span class="order-label">Monthly Price</span>
              <span class="order-value">£${sanitizeNumber(data.plan_price)}/mo</span>
            </div>
            <div class="order-row">
              <span class="order-label">Installation Address</span>
              <span class="order-value">${escapeHtml(data.address_line1)}, ${escapeHtml(data.city)}, ${escapeHtml(data.postcode)}</span>
            </div>
          </div>
        </div>
        
        <!-- What Happens Next -->
        <div class="steps">
          <div class="steps-title">What Happens Next</div>
          <div class="step">
            <div class="step-num">1</div>
            <div class="step-text">We'll review your order within 24 hours and confirm all details.</div>
          </div>
          <div class="step">
            <div class="step-num">2</div>
            <div class="step-text">Our team will reach out to schedule your installation at a time that works for you.</div>
          </div>
          <div class="step">
            <div class="step-num">3</div>
            <div class="step-text">A certified technician will arrive to set everything up — quick and hassle-free.</div>
          </div>
        </div>
        
        <!-- CTA -->
        <div class="cta-wrap">
          <a href="${Deno.env.get("SITE_URL") || "https://occta.co.uk"}/track-order" class="cta">Track Your Order →</a>
        </div>
        
        <!-- Order Number Callout -->
        <div class="order-callout">
          <div class="order-callout-label">Your Order Reference</div>
          <div class="order-callout-number">${escapeHtml(data.order_number)}</div>
        </div>
        
        <p class="text" style="text-align: center; color: #666; font-size: 13px;">
          Keep this number handy — you'll need it to track your order or contact support.
        </p>
      </div>
      
      <!-- Footer -->
      <div class="footer">
        <div class="footer-content">
          <div class="footer-logo">OCCTA</div>
          <div class="footer-links">
            <a href="${Deno.env.get("SITE_URL") || "https://occta.co.uk"}/support" class="footer-link">Support</a>
            <a href="${Deno.env.get("SITE_URL") || "https://occta.co.uk"}/track-order" class="footer-link">Track Order</a>
            <a href="${Deno.env.get("SITE_URL") || "https://occta.co.uk"}" class="footer-link">Website</a>
          </div>
          <div class="footer-text">© ${new Date().getFullYear()} OCCTA Telecom. All rights reserved.</div>
          <div class="footer-address">Questions? Reply to this email or call us at 0800 XXX XXXX</div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
`;

const getWelcomeHtml = (data: Record<string, unknown>) => `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@400;600;700;900&display=swap');
    
    body { margin: 0; padding: 0; background: #f5f4ef; color: #0d0d0d; font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; }
    .preheader { display: none !important; visibility: hidden; opacity: 0; height: 0; width: 0; max-height: 0; max-width: 0; overflow: hidden; }
    
    .wrapper { background: #f5f4ef; padding: 40px 20px; }
    .container { max-width: 600px; margin: 0 auto; background: #ffffff; border: 4px solid #0d0d0d; box-shadow: 8px 8px 0 0 #0d0d0d; }
    
    .header { background: #0d0d0d; padding: 32px; position: relative; overflow: hidden; }
    .header::before { content: ''; position: absolute; top: 0; right: 0; width: 120px; height: 120px; background: #facc15; transform: translate(30%, -30%) rotate(45deg); }
    .logo { font-family: 'Bebas Neue', sans-serif; font-size: 32px; letter-spacing: 4px; color: #ffffff; text-transform: uppercase; position: relative; z-index: 1; }
    .tagline { font-size: 11px; letter-spacing: 3px; text-transform: uppercase; color: #facc15; margin-top: 4px; font-weight: 600; }
    
    .title-banner { background: #facc15; padding: 16px 32px; border-bottom: 4px solid #0d0d0d; }
    .title { font-family: 'Bebas Neue', sans-serif; font-size: 28px; letter-spacing: 2px; text-transform: uppercase; margin: 0; color: #0d0d0d; }
    
    .content { padding: 32px; }
    .greeting { font-size: 18px; font-weight: 700; margin-bottom: 16px; }
    .text { font-size: 15px; line-height: 1.7; color: #333; margin: 16px 0; }
    
    .features { margin: 28px 0; }
    .feature { display: flex; align-items: flex-start; margin: 16px 0; padding: 16px; background: #f5f4ef; border-left: 4px solid #facc15; }
    .feature-icon { width: 40px; height: 40px; background: #0d0d0d; color: #facc15; display: flex; align-items: center; justify-content: center; font-size: 18px; margin-right: 16px; flex-shrink: 0; }
    .feature-text { flex: 1; }
    .feature-title { font-weight: 700; font-size: 14px; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 4px; }
    .feature-desc { font-size: 13px; color: #666; }
    
    .cta-wrap { text-align: center; margin: 32px 0; }
    .cta { display: inline-block; background: #0d0d0d; color: #ffffff; padding: 16px 40px; text-decoration: none; font-family: 'Bebas Neue', sans-serif; font-size: 18px; letter-spacing: 2px; text-transform: uppercase; border: 3px solid #0d0d0d; box-shadow: 4px 4px 0 0 #facc15; }
    
    .footer { background: #0d0d0d; padding: 28px 32px; }
    .footer-content { text-align: center; }
    .footer-logo { font-family: 'Bebas Neue', sans-serif; font-size: 20px; letter-spacing: 3px; color: #facc15; }
    .footer-links { margin: 16px 0; }
    .footer-link { color: #ffffff; text-decoration: none; font-size: 12px; margin: 0 12px; text-transform: uppercase; letter-spacing: 1px; }
    .footer-text { color: #888; font-size: 11px; margin-top: 16px; }
  </style>
</head>
<body>
  <div class="preheader">Welcome to OCCTA! Your account is ready — let's get you connected.</div>
  
  <div class="wrapper">
    <div class="container">
      <div class="header">
        <div class="logo">OCCTA</div>
        <div class="tagline">Telecom • Connected</div>
      </div>
      
      <div class="title-banner">
        <h1 class="title">Welcome Aboard! 🎉</h1>
      </div>
      
      <div class="content">
        <p class="greeting">Hi ${escapeHtml(data.full_name) || "there"},</p>
        <p class="text">You're officially part of the OCCTA family! Your account is all set up and ready to go.</p>
        
        <div class="features">
          <div class="feature">
            <div class="feature-icon">📍</div>
            <div class="feature-text">
              <div class="feature-title">Track Orders</div>
              <div class="feature-desc">Real-time updates on your order and installation status.</div>
            </div>
          </div>
          <div class="feature">
            <div class="feature-icon">⚡</div>
            <div class="feature-text">
              <div class="feature-title">Manage Services</div>
              <div class="feature-desc">Add, upgrade, or modify your services anytime.</div>
            </div>
          </div>
          <div class="feature">
            <div class="feature-icon">💬</div>
            <div class="feature-text">
              <div class="feature-title">Priority Support</div>
              <div class="feature-desc">Get faster responses from our dedicated support team.</div>
            </div>
          </div>
        </div>
        
        <div class="cta-wrap">
          <a href="${Deno.env.get("SITE_URL") || "https://occta.co.uk"}/dashboard" class="cta">Go to Dashboard →</a>
        </div>
        
        <p class="text" style="text-align: center; color: #666; font-size: 13px;">
          Need help getting started? Our support team is just a click away.
        </p>
      </div>
      
      <div class="footer">
        <div class="footer-content">
          <div class="footer-logo">OCCTA</div>
          <div class="footer-links">
            <a href="${Deno.env.get("SITE_URL") || "https://occta.co.uk"}/support" class="footer-link">Support</a>
            <a href="${Deno.env.get("SITE_URL") || "https://occta.co.uk"}/dashboard" class="footer-link">Dashboard</a>
            <a href="${Deno.env.get("SITE_URL") || "https://occta.co.uk"}" class="footer-link">Website</a>
          </div>
          <div class="footer-text">© ${new Date().getFullYear()} OCCTA Telecom. All rights reserved.</div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
`;

const getStatusUpdateHtml = (data: Record<string, unknown>) => {
  const statusConfig: Record<string, { message: string; color: string; icon: string }> = {
    pending: { message: "We've received your order and it's being reviewed by our team.", color: "#facc15", icon: "⏳" },
    confirmed: { message: "Your order has been confirmed! We'll be in touch about installation.", color: "#22c55e", icon: "✓" },
    processing: { message: "We're processing your order and preparing everything for installation.", color: "#3b82f6", icon: "⚙️" },
    dispatched: { message: "Your equipment has been dispatched and is on its way!", color: "#8b5cf6", icon: "📦" },
    installed: { message: "Great news! Your service has been installed. Welcome aboard!", color: "#22c55e", icon: "🏠" },
    active: { message: "Your service is now fully active. Enjoy blazing-fast connectivity!", color: "#22c55e", icon: "🚀" },
    cancelled: { message: "Your order has been cancelled. If you didn't request this, please contact support immediately.", color: "#ef4444", icon: "✕" },
  };

  const config = statusConfig[data.status as string] || { message: "Your order status has been updated.", color: "#facc15", icon: "📋" };
  const safeStatus = escapeHtml(data.status);
  const siteUrl = Deno.env.get("SITE_URL") || "https://occta.co.uk";

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@400;600;700;900&display=swap');
    
    body { margin: 0; padding: 0; background: #f5f4ef; color: #0d0d0d; font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; }
    .preheader { display: none !important; visibility: hidden; opacity: 0; height: 0; width: 0; overflow: hidden; }
    
    .wrapper { background: #f5f4ef; padding: 40px 20px; }
    .container { max-width: 600px; margin: 0 auto; background: #ffffff; border: 4px solid #0d0d0d; box-shadow: 8px 8px 0 0 #0d0d0d; }
    
    .header { background: #0d0d0d; padding: 32px; position: relative; overflow: hidden; }
    .header::before { content: ''; position: absolute; top: 0; right: 0; width: 120px; height: 120px; background: #facc15; transform: translate(30%, -30%) rotate(45deg); }
    .logo { font-family: 'Bebas Neue', sans-serif; font-size: 32px; letter-spacing: 4px; color: #ffffff; text-transform: uppercase; position: relative; z-index: 1; }
    .tagline { font-size: 11px; letter-spacing: 3px; text-transform: uppercase; color: #facc15; margin-top: 4px; font-weight: 600; }
    
    .title-banner { background: ${config.color}; padding: 16px 32px; border-bottom: 4px solid #0d0d0d; }
    .title { font-family: 'Bebas Neue', sans-serif; font-size: 28px; letter-spacing: 2px; text-transform: uppercase; margin: 0; color: #0d0d0d; }
    
    .content { padding: 32px; }
    .greeting { font-size: 18px; font-weight: 700; margin-bottom: 16px; }
    .text { font-size: 15px; line-height: 1.7; color: #333; margin: 16px 0; }
    
    .status-card { text-align: center; background: #f5f4ef; border: 3px solid #0d0d0d; padding: 28px; margin: 24px 0; }
    .status-icon { font-size: 48px; margin-bottom: 12px; }
    .status-badge { display: inline-block; background: #0d0d0d; color: #fff; padding: 8px 24px; font-family: 'Bebas Neue', sans-serif; font-size: 20px; letter-spacing: 2px; text-transform: uppercase; }
    .status-message { font-size: 15px; color: #333; margin-top: 16px; line-height: 1.6; }
    
    .order-info { display: flex; justify-content: space-between; background: #fff; border: 2px solid #0d0d0d; margin: 20px 0; }
    .order-info-item { flex: 1; padding: 16px; text-align: center; border-right: 2px solid #0d0d0d; }
    .order-info-item:last-child { border-right: none; }
    .order-info-label { font-size: 10px; text-transform: uppercase; letter-spacing: 1px; color: #666; }
    .order-info-value { font-weight: 700; font-size: 14px; margin-top: 4px; }
    
    .cta-wrap { text-align: center; margin: 32px 0; }
    .cta { display: inline-block; background: #0d0d0d; color: #ffffff; padding: 16px 40px; text-decoration: none; font-family: 'Bebas Neue', sans-serif; font-size: 18px; letter-spacing: 2px; text-transform: uppercase; border: 3px solid #0d0d0d; box-shadow: 4px 4px 0 0 #facc15; margin: 8px; }
    .cta-secondary { display: inline-block; background: #ffffff; color: #0d0d0d; padding: 14px 32px; text-decoration: none; font-family: 'Bebas Neue', sans-serif; font-size: 16px; letter-spacing: 2px; text-transform: uppercase; border: 3px solid #0d0d0d; margin: 8px; }
    
    .footer { background: #0d0d0d; padding: 28px 32px; }
    .footer-content { text-align: center; }
    .footer-logo { font-family: 'Bebas Neue', sans-serif; font-size: 20px; letter-spacing: 3px; color: #facc15; }
    .footer-text { color: #888; font-size: 11px; margin-top: 16px; }
  </style>
</head>
<body>
  <div class="preheader">Order Update: Your OCCTA order #${escapeHtml(data.order_number)} is now ${safeStatus}.</div>
  
  <div class="wrapper">
    <div class="container">
      <div class="header">
        <div class="logo">OCCTA</div>
        <div class="tagline">Telecom • Connected</div>
      </div>
      
      <div class="title-banner">
        <h1 class="title">${config.icon} Order Update</h1>
      </div>
      
      <div class="content">
        <p class="greeting">Hi ${escapeHtml(data.full_name)},</p>
        <p class="text">Here's the latest on your order:</p>
        
        <div class="status-card">
          <div class="status-icon">${config.icon}</div>
          <div class="status-badge">${safeStatus}</div>
          <p class="status-message">${config.message}</p>
        </div>
        
        <div class="order-info">
          <div class="order-info-item">
            <div class="order-info-label">Order</div>
            <div class="order-info-value">${escapeHtml(data.order_number)}</div>
          </div>
          <div class="order-info-item">
            <div class="order-info-label">Plan</div>
            <div class="order-info-value">${escapeHtml(data.plan_name)}</div>
          </div>
          <div class="order-info-item">
            <div class="order-info-label">Service</div>
            <div class="order-info-value">${escapeHtml(data.service_type)}</div>
          </div>
        </div>
        
        <div class="cta-wrap">
          <a href="${siteUrl}/track-order" class="cta">Track Order →</a>
          <a href="${siteUrl}/auth" class="cta-secondary">Create Account</a>
        </div>
        
        <p class="text" style="text-align: center; color: #666; font-size: 13px;">
          Questions about your order? We're here to help.
        </p>
      </div>
      
      <div class="footer">
        <div class="footer-content">
          <div class="footer-logo">OCCTA</div>
          <div class="footer-text">© ${new Date().getFullYear()} OCCTA Telecom. All rights reserved.</div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
`;
};

const getOrderMessageHtml = (data: Record<string, unknown>) => `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@400;600;700;900&display=swap');
    
    body { margin: 0; padding: 0; background: #f5f4ef; color: #0d0d0d; font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; }
    .preheader { display: none !important; visibility: hidden; opacity: 0; height: 0; width: 0; overflow: hidden; }
    
    .wrapper { background: #f5f4ef; padding: 40px 20px; }
    .container { max-width: 600px; margin: 0 auto; background: #ffffff; border: 4px solid #0d0d0d; box-shadow: 8px 8px 0 0 #0d0d0d; }
    
    .header { background: #0d0d0d; padding: 32px; position: relative; overflow: hidden; }
    .header::before { content: ''; position: absolute; top: 0; right: 0; width: 120px; height: 120px; background: #facc15; transform: translate(30%, -30%) rotate(45deg); }
    .logo { font-family: 'Bebas Neue', sans-serif; font-size: 32px; letter-spacing: 4px; color: #ffffff; text-transform: uppercase; position: relative; z-index: 1; }
    .tagline { font-size: 11px; letter-spacing: 3px; text-transform: uppercase; color: #facc15; margin-top: 4px; font-weight: 600; }
    
    .title-banner { background: #3b82f6; padding: 16px 32px; border-bottom: 4px solid #0d0d0d; }
    .title { font-family: 'Bebas Neue', sans-serif; font-size: 28px; letter-spacing: 2px; text-transform: uppercase; margin: 0; color: #ffffff; }
    
    .content { padding: 32px; }
    .greeting { font-size: 18px; font-weight: 700; margin-bottom: 16px; }
    .text { font-size: 15px; line-height: 1.7; color: #333; margin: 16px 0; }
    
    .order-ref { display: inline-block; background: #facc15; padding: 4px 12px; font-weight: 700; font-size: 14px; }
    
    .message-box { background: #f5f4ef; border: 3px solid #0d0d0d; padding: 24px; margin: 24px 0; position: relative; }
    .message-box::before { content: '"'; font-family: 'Bebas Neue', sans-serif; font-size: 64px; color: #facc15; position: absolute; top: -10px; left: 16px; line-height: 1; }
    .message-content { font-size: 15px; line-height: 1.7; padding-left: 40px; font-style: italic; }
    
    .cta-wrap { text-align: center; margin: 32px 0; }
    .cta { display: inline-block; background: #0d0d0d; color: #ffffff; padding: 16px 40px; text-decoration: none; font-family: 'Bebas Neue', sans-serif; font-size: 18px; letter-spacing: 2px; text-transform: uppercase; border: 3px solid #0d0d0d; box-shadow: 4px 4px 0 0 #facc15; }
    
    .footer { background: #0d0d0d; padding: 28px 32px; }
    .footer-content { text-align: center; }
    .footer-logo { font-family: 'Bebas Neue', sans-serif; font-size: 20px; letter-spacing: 3px; color: #facc15; }
    .footer-text { color: #888; font-size: 11px; margin-top: 16px; }
  </style>
</head>
<body>
  <div class="preheader">New message about your OCCTA order #${escapeHtml(data.order_number)}</div>
  
  <div class="wrapper">
    <div class="container">
      <div class="header">
        <div class="logo">OCCTA</div>
        <div class="tagline">Telecom • Connected</div>
      </div>
      
      <div class="title-banner">
        <h1 class="title">💬 New Message</h1>
      </div>
      
      <div class="content">
        <p class="greeting">Hi ${escapeHtml(data.full_name)},</p>
        <p class="text">We have an update regarding your order <span class="order-ref">${escapeHtml(data.order_number)}</span>:</p>
        
        <div class="message-box">
          <p class="message-content">${escapeHtml(data.message)}</p>
        </div>
        
        <p class="text">Have questions or need to respond? Log in to your dashboard or get in touch with our support team.</p>
        
        <div class="cta-wrap">
          <a href="${Deno.env.get("SITE_URL") || "https://occta.co.uk"}/dashboard" class="cta">View Order →</a>
        </div>
      </div>
      
      <div class="footer">
        <div class="footer-content">
          <div class="footer-logo">OCCTA</div>
          <div class="footer-text">© ${new Date().getFullYear()} OCCTA Telecom. All rights reserved.</div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
`;

const getTicketReplyHtml = (data: Record<string, unknown>) => `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@400;600;700;900&display=swap');
    
    body { margin: 0; padding: 0; background: #f5f4ef; color: #0d0d0d; font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; }
    .preheader { display: none !important; visibility: hidden; opacity: 0; height: 0; width: 0; overflow: hidden; }
    
    .wrapper { background: #f5f4ef; padding: 40px 20px; }
    .container { max-width: 600px; margin: 0 auto; background: #ffffff; border: 4px solid #0d0d0d; box-shadow: 8px 8px 0 0 #0d0d0d; }
    
    .header { background: #0d0d0d; padding: 32px; position: relative; overflow: hidden; }
    .header::before { content: ''; position: absolute; top: 0; right: 0; width: 120px; height: 120px; background: #facc15; transform: translate(30%, -30%) rotate(45deg); }
    .logo { font-family: 'Bebas Neue', sans-serif; font-size: 32px; letter-spacing: 4px; color: #ffffff; text-transform: uppercase; position: relative; z-index: 1; }
    .tagline { font-size: 11px; letter-spacing: 3px; text-transform: uppercase; color: #facc15; margin-top: 4px; font-weight: 600; }
    
    .title-banner { background: #22c55e; padding: 16px 32px; border-bottom: 4px solid #0d0d0d; }
    .title { font-family: 'Bebas Neue', sans-serif; font-size: 28px; letter-spacing: 2px; text-transform: uppercase; margin: 0; color: #ffffff; }
    
    .content { padding: 32px; }
    .greeting { font-size: 18px; font-weight: 700; margin-bottom: 16px; }
    .text { font-size: 15px; line-height: 1.7; color: #333; margin: 16px 0; }
    
    .ticket-subject { background: #0d0d0d; color: #fff; padding: 16px 20px; margin: 20px 0; }
    .ticket-label { font-size: 10px; text-transform: uppercase; letter-spacing: 2px; color: #facc15; margin-bottom: 4px; }
    .ticket-title { font-family: 'Bebas Neue', sans-serif; font-size: 18px; letter-spacing: 1px; }
    
    .message-box { background: #f5f4ef; border: 3px solid #0d0d0d; padding: 24px; margin: 20px 0; }
    .message-label { font-size: 10px; text-transform: uppercase; letter-spacing: 2px; color: #666; margin-bottom: 12px; font-weight: 600; }
    .message-content { font-size: 15px; line-height: 1.7; }
    
    .cta-wrap { text-align: center; margin: 32px 0; }
    .cta { display: inline-block; background: #0d0d0d; color: #ffffff; padding: 16px 40px; text-decoration: none; font-family: 'Bebas Neue', sans-serif; font-size: 18px; letter-spacing: 2px; text-transform: uppercase; border: 3px solid #0d0d0d; box-shadow: 4px 4px 0 0 #facc15; }
    
    .footer { background: #0d0d0d; padding: 28px 32px; }
    .footer-content { text-align: center; }
    .footer-logo { font-family: 'Bebas Neue', sans-serif; font-size: 20px; letter-spacing: 3px; color: #facc15; }
    .footer-text { color: #888; font-size: 11px; margin-top: 16px; }
  </style>
</head>
<body>
  <div class="preheader">Our support team has replied to your ticket: ${escapeHtml(data.ticket_subject)}</div>
  
  <div class="wrapper">
    <div class="container">
      <div class="header">
        <div class="logo">OCCTA</div>
        <div class="tagline">Telecom • Connected</div>
      </div>
      
      <div class="title-banner">
        <h1 class="title">✓ Support Reply</h1>
      </div>
      
      <div class="content">
        <p class="greeting">Hi ${escapeHtml(data.full_name)},</p>
        <p class="text">Good news! Our support team has replied to your ticket:</p>
        
        <div class="ticket-subject">
          <div class="ticket-label">Ticket Subject</div>
          <div class="ticket-title">RE: ${escapeHtml(data.ticket_subject)}</div>
        </div>
        
        <div class="message-box">
          <div class="message-label">Support Response</div>
          <p class="message-content">${escapeHtml(data.message)}</p>
        </div>
        
        <p class="text">You can continue the conversation from your dashboard.</p>
        
        <div class="cta-wrap">
          <a href="${Deno.env.get("SITE_URL") || "https://occta.co.uk"}/dashboard" class="cta">View Ticket →</a>
        </div>
      </div>
      
      <div class="footer">
        <div class="footer-content">
          <div class="footer-logo">OCCTA</div>
          <div class="footer-text">© ${new Date().getFullYear()} OCCTA Telecom. All rights reserved.</div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
`;

const getPasswordResetHtml = (data: Record<string, unknown>) => `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Inter:wght@400;600;700;900&display=swap');
    
    body { margin: 0; padding: 0; background: #f5f4ef; color: #0d0d0d; font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; }
    .preheader { display: none !important; visibility: hidden; opacity: 0; height: 0; width: 0; overflow: hidden; }
    
    .wrapper { background: #f5f4ef; padding: 40px 20px; }
    .container { max-width: 600px; margin: 0 auto; background: #ffffff; border: 4px solid #0d0d0d; box-shadow: 8px 8px 0 0 #0d0d0d; }
    
    .header { background: #0d0d0d; padding: 32px; position: relative; overflow: hidden; }
    .header::before { content: ''; position: absolute; top: 0; right: 0; width: 120px; height: 120px; background: #facc15; transform: translate(30%, -30%) rotate(45deg); }
    .logo { font-family: 'Bebas Neue', sans-serif; font-size: 32px; letter-spacing: 4px; color: #ffffff; text-transform: uppercase; position: relative; z-index: 1; }
    .tagline { font-size: 11px; letter-spacing: 3px; text-transform: uppercase; color: #facc15; margin-top: 4px; font-weight: 600; }
    
    .title-banner { background: #ef4444; padding: 16px 32px; border-bottom: 4px solid #0d0d0d; }
    .title { font-family: 'Bebas Neue', sans-serif; font-size: 28px; letter-spacing: 2px; text-transform: uppercase; margin: 0; color: #ffffff; }
    
    .content { padding: 32px; }
    .greeting { font-size: 18px; font-weight: 700; margin-bottom: 16px; }
    .text { font-size: 15px; line-height: 1.7; color: #333; margin: 16px 0; }
    
    .cta-wrap { text-align: center; margin: 32px 0; }
    .cta { display: inline-block; background: #0d0d0d; color: #ffffff; padding: 18px 48px; text-decoration: none; font-family: 'Bebas Neue', sans-serif; font-size: 20px; letter-spacing: 2px; text-transform: uppercase; border: 3px solid #0d0d0d; box-shadow: 4px 4px 0 0 #facc15; }
    
    .security-note { background: #fef3c7; border: 3px solid #facc15; padding: 20px; margin: 24px 0; }
    .security-icon { font-size: 24px; margin-bottom: 8px; }
    .security-title { font-weight: 700; font-size: 14px; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px; }
    .security-text { font-size: 13px; color: #666; line-height: 1.6; }
    
    .footer { background: #0d0d0d; padding: 28px 32px; }
    .footer-content { text-align: center; }
    .footer-logo { font-family: 'Bebas Neue', sans-serif; font-size: 20px; letter-spacing: 3px; color: #facc15; }
    .footer-text { color: #888; font-size: 11px; margin-top: 16px; }
  </style>
</head>
<body>
  <div class="preheader">Reset your OCCTA account password — this link expires soon.</div>
  
  <div class="wrapper">
    <div class="container">
      <div class="header">
        <div class="logo">OCCTA</div>
        <div class="tagline">Telecom • Connected</div>
      </div>
      
      <div class="title-banner">
        <h1 class="title">🔐 Password Reset</h1>
      </div>
      
      <div class="content">
        <p class="greeting">Hi ${escapeHtml(data.full_name) || "there"},</p>
        <p class="text">We received a request to reset your OCCTA account password. Click the button below to choose a new one:</p>
        
        <div class="cta-wrap">
          <a href="${escapeHtml(data.reset_link)}" class="cta">Reset Password →</a>
        </div>
        
        <div class="security-note">
          <div class="security-icon">🛡️</div>
          <div class="security-title">Security Notice</div>
          <p class="security-text">If you didn't request this password reset, you can safely ignore this email. Your password will remain unchanged. For security, this link will expire in 1 hour.</p>
        </div>
        
        <p class="text" style="text-align: center; color: #666; font-size: 13px;">
          Need help? Contact our support team anytime.
        </p>
      </div>
      
      <div class="footer">
        <div class="footer-content">
          <div class="footer-logo">OCCTA</div>
          <div class="footer-text">© ${new Date().getFullYear()} OCCTA Telecom. All rights reserved.</div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
`;

// Helper to verify user is admin
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const isAdmin = async (supabase: any, userId: string): Promise<boolean> => {
  const { data, error } = await supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "admin")
    .maybeSingle();
  
  return !error && data !== null;
};

// Helper to validate email format
const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email) && email.length <= 254;
};

const handler = async (req: Request): Promise<Response> => {
  console.log("Email function called");
  
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Parse request body first to determine auth requirements
    const { type, to, data, orderNumber, redirectTo }: EmailRequest = await req.json();

    if (!resendApiKey) {
      console.error("Missing RESEND_API_KEY");
      return new Response(
        JSON.stringify({ error: "Email service is not configured" }),
        { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }
    
    // Validate email format
    if (!isValidEmail(to)) {
      console.error("Invalid email format:", to);
      return new Response(
        JSON.stringify({ error: "Invalid email address format" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Create unauthenticated Supabase client for verification
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Handle order_confirmation for guest orders (no auth required, but verify order exists)
    if (type === "order_confirmation" && orderNumber) {
      // Verify the order exists and email matches
      const { data: guestOrder, error: orderError } = await supabaseAdmin
        .from("guest_orders")
        .select("email, order_number")
        .eq("order_number", orderNumber)
        .single();
      
      if (orderError || !guestOrder) {
        console.error("Order not found:", orderNumber);
        return new Response(
          JSON.stringify({ error: "Order not found" }),
          { status: 404, headers: { "Content-Type": "application/json", ...corsHeaders } }
        );
      }
      
      if (guestOrder.email.toLowerCase() !== to.toLowerCase()) {
        console.error("Email mismatch for order confirmation");
        return new Response(
          JSON.stringify({ error: "Forbidden - Email recipient mismatch" }),
          { status: 403, headers: { "Content-Type": "application/json", ...corsHeaders } }
        );
      }
      
      console.log(`Verified guest order confirmation for ${orderNumber}`);
    } else {
      // All other email types require authentication
      const authHeader = req.headers.get("Authorization");
      if (!authHeader?.startsWith("Bearer ")) {
        console.error("No authorization header provided");
        return new Response(
          JSON.stringify({ error: "Unauthorized - No authorization header" }),
          { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
        );
      }

      const supabase = createClient(
        Deno.env.get("SUPABASE_URL") ?? "",
        Deno.env.get("SUPABASE_ANON_KEY") ?? "",
        { global: { headers: { Authorization: authHeader } } }
      );

      // Verify JWT token
      const token = authHeader.replace("Bearer ", "");
      const { data: claimsData, error: claimsError } = await supabase.auth.getClaims(token);
      
      if (claimsError || !claimsData?.claims) {
        console.error("Invalid token:", claimsError?.message);
        return new Response(
          JSON.stringify({ error: "Unauthorized - Invalid token" }),
          { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
        );
      }

      const userId = claimsData.claims.sub as string;
      console.log(`Authenticated user: ${userId}`);

      // Authorization checks based on email type
      if (type === "status_update" || type === "order_message" || type === "ticket_reply" || type === "password_reset") {
        // Only admins can send these email types
        const userIsAdmin = await isAdmin(supabase, userId);
        if (!userIsAdmin) {
          console.error("User is not admin, cannot send this email type");
          return new Response(
            JSON.stringify({ error: "Forbidden - Admin access required" }),
            { status: 403, headers: { "Content-Type": "application/json", ...corsHeaders } }
          );
        }
        console.log(`Admin verified for ${type} email`);
      } else if (type === "order_confirmation") {
        // For authenticated order confirmations, verify the email matches the order recipient
        const orderEmail = data.email as string | undefined;
        if (orderEmail && orderEmail.toLowerCase() !== to.toLowerCase()) {
          console.error("Email mismatch: order email vs recipient");
          return new Response(
            JSON.stringify({ error: "Forbidden - Email recipient mismatch" }),
            { status: 403, headers: { "Content-Type": "application/json", ...corsHeaders } }
          );
        }
      } else if (type === "welcome") {
        // Welcome emails should only be sent to the authenticated user's email
        const { data: profile } = await supabase
          .from("profiles")
          .select("email")
          .eq("id", userId)
          .single();
        
        if (profile?.email && profile.email.toLowerCase() !== to.toLowerCase()) {
          console.error("Welcome email can only be sent to user's own email");
          return new Response(
            JSON.stringify({ error: "Forbidden - Can only send welcome email to own address" }),
            { status: 403, headers: { "Content-Type": "application/json", ...corsHeaders } }
          );
        }
      }
    }

    console.log(`Sending ${type} email to ${to}`);

    let subject: string;
    let html: string;
    let emailData: Record<string, unknown> = { ...data };

    if (type === "password_reset") {
      const { data: linkData, error: linkError } = await supabaseAdmin.auth.admin.generateLink({
        type: "recovery",
        email: to,
        options: redirectTo ? { redirectTo } : undefined,
      });

      const resetLink = linkData?.properties?.action_link;

      if (linkError || !resetLink) {
        console.error("Failed to generate password reset link", linkError?.message);
        return new Response(
          JSON.stringify({ error: "Unable to generate password reset link" }),
          { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
        );
      }

      emailData = { ...emailData, reset_link: resetLink };
    }

    switch (type) {
      case "order_confirmation":
        subject = `Order Confirmed - ${data?.order_number || orderNumber || 'N/A'}`;
        html = getOrderConfirmationHtml({ ...emailData, order_number: data?.order_number || orderNumber });
        break;
      case "welcome":
        subject = "Welcome to OCCTA!";
        html = getWelcomeHtml(emailData);
        break;
      case "status_update":
        subject = `Order Update - ${data?.order_number || orderNumber || 'N/A'}: ${(data?.status as string || 'UPDATED').toUpperCase()}`;
        html = getStatusUpdateHtml(emailData);
        break;
      case "order_message":
        subject = `Message About Your Order - ${data?.order_number || orderNumber || 'N/A'}`;
        html = getOrderMessageHtml(emailData);
        break;
      case "ticket_reply":
        subject = `Support Ticket Reply: ${data.ticket_subject}`;
        html = getTicketReplyHtml(emailData);
        break;
      case "password_reset":
        subject = "Reset your OCCTA password";
        html = getPasswordResetHtml(emailData);
        break;
      default:
        throw new Error(`Unknown email type: ${type}`);
    }

    // Use RESEND_FROM_EMAIL for all emails - this must be a verified domain in Resend
    const fromEmail = Deno.env.get("RESEND_FROM_EMAIL") || "onboarding@resend.dev";
    
    // Get admin email for BCC (if configured)
    const adminEmail = Deno.env.get("ADMIN_EMAIL");
    const bccList = type === "order_confirmation" && adminEmail ? [adminEmail] : undefined;
    
    const emailResponse = await resend.emails.send({
      from: `OCCTA Telecom <${fromEmail}>`,
      to: [to],
      bcc: bccList,
      subject,
      html,
    });

    if ("error" in emailResponse && emailResponse.error) {
      console.error("Resend email error:", emailResponse.error);
      return new Response(
        JSON.stringify({ error: emailResponse.error.message || "Email send failed" }),
        {
          status: 502,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    console.log("Email sent successfully:", emailResponse);

    return new Response(JSON.stringify(emailResponse), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Error in send-email function:", errorMessage);
    return new Response(
      JSON.stringify({ error: errorMessage }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
